import 'package:flutter/material.dart';
import 'package:fixnixt1/rcard.dart';
import 'package:fixnixt1/consts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fixnixt1/icon_content.dart';
import 'package:fixnixt1/formh.dart';
import 'bottom_button.dart';
import 'package:flutter/services.dart';
import 'components/cancel_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: MyHomePage(title: 'Fitness Classes'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String selectedService;

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.blueGrey, //or set color with: Color(0xFF0000FF)
    ));
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text(widget.title)),
        backgroundColor: Colors.blueGrey,
      ),
      body: Container(
        color: Color(0xfff5f5f5),
        child: Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              BottomButton(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return CancelScreen();
                      },
                    ),
                  );
                },
                buttonTitle: 'CANCEL ALL SLOTS',
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    child: Text(
                      'SELECT YOUR CLASS',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color(0x00ffffff),
                      ),
                    ),
                  ),
                  Container(
                    child: Text(
                      'SELECT YOUR CLASS',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color(0xff212121),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: ReusableCard(
                          onPress: () {
                            setState(() {
                              selectedService = 'yoga';
                            });
                          },
                          colour: selectedService == 'yoga'
                              ? kActiveCardColor
                              : kInactiveCardColor,
                          cardChild: IconContent(
                            icon: FontAwesomeIcons.infinity,
                            label: 'YOGA',
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: ReusableCard(
                          onPress: () {
                            setState(() {
                              selectedService = 'gym';
                            });
                          },
                          colour: selectedService == 'gym'
                              ? kActiveCardColor
                              : kInactiveCardColor,
                          cardChild: IconContent(
                            icon: FontAwesomeIcons.weight,
                            label: 'GYM',
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: ReusableCard(
                          onPress: () {
                            setState(() {
                              selectedService = 'dance';
                            });
                          },
                          colour: selectedService == 'dance'
                              ? kActiveCardColor
                              : kInactiveCardColor,
                          cardChild: IconContent(
                            icon: FontAwesomeIcons.accusoft,
                            label: 'DANCE',
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
              BottomButton(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return Filler(
                          chosenService: selectedService,
                        );
                      },
                    ),
                  );
                },
                buttonTitle: 'SELECT',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
