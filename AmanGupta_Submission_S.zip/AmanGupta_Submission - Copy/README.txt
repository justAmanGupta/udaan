NOTE: This is a flutter app which can be deployed on Andorid, IOS, Windows, Macos etc. This has been made in Android Studio so it can be right away tested in android by following the given steps.


Prerequisite:
Android Studio with Flutter Installed.

1)Folder named "fitness_slot_b_s" is the project folder.
2)Open the above folder via android studio.
3)Run the project in an emulator.

PS. -> Some images have been provided in this folder for reference so that
app can be seen before installing on an emulator. Due to time constraints, unfortunately, some backend functionalities are not there which could have been implemented if the front end faster was made faster.